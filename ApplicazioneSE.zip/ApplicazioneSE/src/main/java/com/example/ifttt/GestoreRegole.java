package com.example.ifttt;

import javafx.collections.ObservableList;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;


public class GestoreRegole implements Runnable {

private static int contatore = 1;
    public static ObservableList<Regola> listaRegole = CreaRegolaController.lista;
    private final int ripetiVerifica = 3;




    public GestoreRegole(ObservableList<Regola> listaRegole) {
        this.listaRegole = listaRegole;
    }


    @Override
    public void run() {

        while (!Thread.currentThread().isInterrupted()) {

            synchronized (listaRegole) {

                //Itero sugli elementi della lista//
                for (Regola a : listaRegole) {
                    a.valutaEsecuzione();
                    if (a.valutaEsecuzione()== true ){
                        a.setEseguito(true);
                        a.setStato(false);
                    }
                }
            }

            try {

                Thread.sleep(ripetiVerifica * 1000);

            } catch (InterruptedException ex) {

                Logger.getLogger(GestoreRegole.class.getName());

            }

        }

    }


    //-----METODI PER GESTIRE LE REGOLE-----//
    public void aggiungiRegola(Regola nuovaRegola) {

        listaRegole.add(nuovaRegola);
    }





    @Override
    public String toString() {
        return "GestoreRegole{" +
                "listaRegole=" + listaRegole +
                '}';
    }




    public void saveObjectsToFile() {
        // Specificare il percorso del file JSON
        Path filePath = Paths.get("ListaRegole.json");

        JSONObject jsonContainer;

        // Check if the file already exists
        if (Files.exists(filePath)) {
            // If the file exists, read its content into the existing JSONObject
            try {
                String fileContent = new String(Files.readAllBytes(filePath));

                jsonContainer = new JSONObject(fileContent);


                // Update contatore to the maximum ID from existing rules
                updateContatoreFromExistingRules(jsonContainer.getJSONArray("regole"));

            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("Errore durante la lettura del file JSON esistente.");
                return;
            }
        } else {
            // If the file doesn't exist, create a new JSONObject with an empty array
            jsonContainer = new JSONObject();
            jsonContainer.put("regole", new JSONArray());
        }

        synchronized (listaRegole) {
            JSONArray jsonArray = jsonContainer.getJSONArray("regole");

            // Check if the rule already exists in the JSONArray based on the name
            Set<String> existingRuleNames = new HashSet<>();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject existingRule = jsonArray.getJSONObject(i);
                existingRuleNames.add(existingRule.getString("nome"));
            }

            // Add new rules to the JSONArray based on the name
            for (Regola regola : listaRegole) {
                if (!existingRuleNames.contains(regola.getNome())) {
                    // Use the updated contatore for the new ID
                    regola.setID(contatore);
                    jsonArray.put(regola.toJSONObject());
                    existingRuleNames.add(regola.getNome());
                    contatore++; // Increment contatore for the next ID
                }
            }

            try {
                // Sovrascrivere il file JSON con il JSONObject aggiornato
                Files.write(filePath, jsonContainer.toString(2).getBytes(), StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                System.out.println("Regole aggiunte con successo al file JSON.");
            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("Errore durante la scrittura nel file JSON.");
            }
        }
    }

    // Metodo per aggiornare il contatore in base alle regole esistenti
    private void updateContatoreFromExistingRules(JSONArray existingRules) {
        for (int i = 0; i < existingRules.length(); i++) {
            JSONObject existingRule = existingRules.getJSONObject(i);
            int existingID = existingRule.getInt("ID");
            contatore = Math.max(contatore, existingID + 1);
        }
    }

}

