package com.example.ifttt;


import org.json.JSONObject;

import java.io.*;
import java.time.Duration;
import java.util.Objects;

public class Regola implements Serializable {


    private int ID;
    private final String nome;
    private Trigger t;
    private Azione a;
    private boolean stato;
    private boolean eseguito;
    private boolean ripetibile;

    private Duration periodoIbernazione;

    private static int contatore = 1;



    //-----COSTRUTTORE-----//
    public Regola(String nome, Trigger t, Azione a, boolean stato, boolean eseguito, boolean ripetibile) {
        this.ID = contatore;
        this.nome = nome ;
        this.t = t;
        this.a = a;
        this.stato = stato;
        contatore++;
        this.eseguito = eseguito;
        this.ripetibile = ripetibile;
    }
    //---------------------//

    public Regola(String nome, Trigger t, Azione a, boolean stato, boolean eseguito, boolean ripetibile, Duration periodoIbernazione) {
        this.ID = ID;
        this.nome = nome ;
        this.t = t;
        this.a = a;
        this.stato = stato;
        this.eseguito = eseguito;
        this.ripetibile = ripetibile;
        this.periodoIbernazione = periodoIbernazione;
    }

    public Regola(int ID, String nome, Trigger t, Azione a, boolean stato, boolean eseguito, boolean ripetibile, Duration periodoIbernazione) {
        this.ID = ID;
        this.nome = nome ;
        this.t = t;
        this.a = a;
        this.stato = stato;
        this.eseguito = eseguito;
        this.ripetibile = ripetibile;
        this.periodoIbernazione = periodoIbernazione;
    }

    // Nuovo costruttore con ID
    public Regola(int ID, String nome, Trigger t, Azione a, boolean stato, boolean eseguito) {
        this.ID = ID;
        this.nome = nome;
        this.t = t;
        this.a = a;
        this.stato = stato;
        this.eseguito = eseguito;
    }

    public boolean valutaEsecuzione(){

        if(t.verificaCondizione()){

            if(!eseguito && stato){

                a.eseguiAzione();
                eseguito = true;
                stato = false;
                return true;

            }

            return false;
        }

        return false;

    }



    public JSONObject toJSONObject() {
        JSONObject regolaJson = new JSONObject();
        regolaJson.put("ID", ID);
        regolaJson.put("nome", nome);
        regolaJson.put("trigger", t.toJSONObject());
        regolaJson.put("azione", a.toJSONObject());
        regolaJson.put("stato", stato);
        regolaJson.put("eseguito", eseguito);
        regolaJson.put("ripetibile", ripetibile);
        if (ripetibile == true) {
            regolaJson.put("ibernazione", periodoIbernazione);
        }

        return regolaJson;
    }

    //-----GETTER & SETTER-----//

    public int getID() {
        return ID;
    }

    public String getNome() {
        return nome;
    }

    public Trigger getTrigger() {
        return t;
    }

    public Azione getAzione() {
        return a;
    }


    public String getStato() {

        if (stato == true)
            return "Attiva";
        else
            return "Disattiva";
    }

    public boolean isEseguito() {
        return eseguito;
    }

    public static int getContatore() {
        return contatore;
    }

    public String getRipetibile() {
        if (ripetibile == true) {
            IbernazioneController i = new IbernazioneController(periodoIbernazione);
            return "Dopo: " + i;
        }
        else
            return "No";
    }

    public boolean isRipetibile() {
        return ripetibile;
    }

    public void setRipetibile(boolean ripetibile) {
        this.ripetibile = ripetibile;
    }

    public void setT(Trigger t) {
        this.t = t;
    }

    public void setStato(boolean stato) {
        this.stato = stato;
    }

    public void setEseguito(boolean eseguito) {
        this.eseguito = eseguito;
    }

    public void attivaRegola(Regola regolaDaAttivare) {
        regolaDaAttivare.setStato(true);
    }

    public void disattivaRegola(Regola regolaDaDisattivare) {
        regolaDaDisattivare.setStato(false);
    }

    public static void setContatore(int contatore) {
        Regola.contatore = contatore;
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Regola regola = (Regola) o;
        return ID == regola.ID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID);
    }


    @Override
    public String toString() {
        return "Regola: {" +
                "ID = " + ID +
                ", Nome = '" + nome + '\'' +
                ", Trigger = " + t +
                ", Azione = " + a +
                ", Stato =" + stato +
                ", Eseguito = " + eseguito +
                ", Ripetibile = " +ripetibile +
                '}';
    }

    public void setID(int ID) {
        this.ID = ID;
    }
}