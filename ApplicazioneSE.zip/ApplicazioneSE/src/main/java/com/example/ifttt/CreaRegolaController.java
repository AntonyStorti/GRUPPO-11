package com.example.ifttt;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.FileChooser;
import java.io.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collections;


public class CreaRegolaController {


    @FXML
    private ChoiceBox<String> sceltaTrigger;
    @FXML
    private ChoiceBox<String> sceltaAzione;
    @FXML
    private TextField sceltaNome;
    @FXML
    private Button inviaButton;
    @FXML
    private CheckBox ripetibile;


    public static ObservableList<Regola> lista = FXCollections.observableArrayList();

    public static RiproduciAudio tracciaAudio;
    public static EseguiProgramma app;
    public static EliminaFile path;



    private HelloController helloController;



    //Tipi di Trigger;
    private String sceltaOra = "Seleziona un orario";
    private String sceltaGiorno = "Seleziona un giorno";
    private String sceltaGMese = "Seleziona un giorno del mese";
    private String sceltaData = "Seleziona una data";
    private String esisteFile = "Se esiste un File";
    private String dimFile = "Se la dimensione del file è > di";



    //Tipi di Azione:
    private String sceltaMes = "Visualizza messaggio";
    private String sceltaAud = "Riproduci un audio";
    private String sceltaPro = "Esegui un programma";
    private String sceltaStringa = "Aggiungi una stringa";
    private String sceltaEliminaFile = "Elimina un file";
    private String sceltaCopiaSposta = "Copia/Sposta un file";




    @FXML
    private void initialize() {
        sceltaTrigger.setOnAction(event -> apriFinestraSceltaTrigger());
        sceltaAzione.setOnAction(event -> apriFinestraSceltaAzioni());
        inviaButton.setOnAction(event -> creaRegola());
        ripetibile.setOnAction(actionEvent -> ripetiAzione());
    }


    public void setHelloController(HelloController helloController) {
        this.helloController = helloController;
    }

    public void apriFinestraSceltaTrigger() {

        String selectedItem = sceltaTrigger.getSelectionModel().getSelectedItem();


        if (selectedItem.equals(sceltaOra)){

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("SceltaOra.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Seleziona un orario...");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        }

        if (selectedItem.equals(sceltaGiorno)){

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("GiornoSettimana.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Seleziona un giorno...");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        }

        if (selectedItem.equals(sceltaGMese)){

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("GiornoMese.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Seleziona un giorno del mese...");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        }

        if (selectedItem.equals(sceltaData)){

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("DataCompleta.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Seleziona una data...");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        }

        if (selectedItem.equals(esisteFile)){

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("FileEsiste.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Se esiste questo file nella cartella...");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }


        }

        if (selectedItem.equals(dimFile)){

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("DimensioneFile.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Se questo file ha dimensioni superiori a...");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        }

    }



    public void apriFinestraSceltaAzioni() {

        String selectedItem = sceltaAzione.getSelectionModel().getSelectedItem();

        
        if (selectedItem.equals(sceltaMes)) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("FinestraDialogo.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Scrivi il tuo messaggio...");
                stage.setScene(new Scene(root));
                stage.show();

            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

            
        } else if (selectedItem.equals(sceltaAud)) {

            try {
                // Creare un oggetto FileChooser
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Seleziona un file audio (.mp3, .waw, .mp4...)");
                fileChooser.getExtensionFilters().addAll(
                        new FileChooser.ExtensionFilter("File audio", "*.wav")
                );

                Stage stage = (Stage) sceltaAzione.getScene().getWindow();
                File fileSelezionato = fileChooser.showOpenDialog(stage);


                // Verifica se è stato selezionato un file
                if (fileSelezionato != null) {
                    // Salva il percorso del file selezionato
                    String percorsoFileAudio = fileSelezionato.getAbsolutePath();
                    tracciaAudio = new RiproduciAudio(percorsoFileAudio);
                }

            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        } else if (selectedItem.equals(sceltaPro)){

            try {
                // Creare un oggetto FileChooser
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Seleziona il programma da eseguire...");
                fileChooser.getExtensionFilters().addAll(
                        new FileChooser.ExtensionFilter("File eseguibile", "*.exe", "*.app")
                );

                Stage stage = (Stage) sceltaAzione.getScene().getWindow();
                File fileSelezionato = fileChooser.showOpenDialog(stage);


                // Verifica se è stato selezionato un file
                if (fileSelezionato != null) {
                    // Salva il percorso del file selezionato
                    String percorsoAPP = fileSelezionato.getAbsolutePath();
                    app = new EseguiProgramma(percorsoAPP);
                }
            } catch (Exception e) {
            e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        } else if (selectedItem.equals(sceltaStringa)) {

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("AggiungiStringa.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Scrivi la stringa da aggiungere...");
                stage.setScene(new Scene(root));
                stage.show();

            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        } else if (selectedItem.equals(sceltaEliminaFile)){

            try {
                // Creare un oggetto FileChooser
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Seleziona il file da eliminare...");
                fileChooser.getExtensionFilters().addAll(
                        new FileChooser.ExtensionFilter("File di testo", "*.txt")
                );

                Stage stage = (Stage) sceltaAzione.getScene().getWindow();
                File fileSelezionato = fileChooser.showOpenDialog(stage);


                // Verifica se è stato selezionato un file
                if (fileSelezionato != null) {
                    // Salva il percorso del file selezionato
                    String percorso = fileSelezionato.getAbsolutePath();
                    path = new EliminaFile(percorso);
                }
            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        } else if (selectedItem.equals(sceltaCopiaSposta)) {

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("SorgenteDestinazione.fxml"));
                Parent root = loader.load();
                Stage stage = new Stage();
                stage.setTitle("Opera sui tuoi File...");
                stage.setScene(new Scene(root));
                stage.show();

            } catch (Exception e) {
                e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
            }

        }
    }



    public void creaRegola(){

        String nome = sceltaNome.getText();
        String selectedTrigger = sceltaTrigger.getValue();
        String selectedAzione = sceltaAzione.getValue();


        Trigger t = null;
        Azione a = null;


        if (selectedTrigger.equals(sceltaOra)) {
            LocalTime ora = SceltaOraController.orarioScelto;
            t = new TempoDelGiorno(ora);
        }
        if (selectedTrigger.equals(sceltaGiorno)){
            DayOfWeek giorno = GiornoSettimanaController.giorno;
            t = new TriggerSettimanale(LocalTime.of(0, 0), giorno);
        }
        if (selectedTrigger.equals(sceltaGMese)) {
            LocalDate gmese = GiornoMeseController.gMese;
            t = new TriggerMensile(LocalTime.of(17, 23), gmese);
        }
        if (selectedTrigger.equals(sceltaData)) {
            LocalDate data = DataCompletaController.dCompleta;
            t = new TriggerSuData(LocalTime.of(0, 0), data);
        }
        if (selectedTrigger.equals(esisteFile)){
            String nomeFile = FileEsisteController.nFile;
            String cartella = FileEsisteController.directory;
            t = new FileEsiste(cartella, nomeFile);
        }
        if (selectedTrigger.equals(dimFile)){
            String f = DimensioneFileController.file;
            int dimMAX = DimensioneFileController.dim;
            String unita = DimensioneFileController.unita;
            t = new DimensioneFile(f,dimMAX, unita);

        }





        if (selectedAzione.equals(sceltaMes)) {
            String messaggio = FinestraDialogoController.messUtente;
            a = new FinestraDialogo(messaggio);
        }
        if (selectedAzione.equals(sceltaAud)) {
            a = tracciaAudio;
        }
        if (selectedAzione.equals(sceltaPro)) {
            a = app;
        }
        if (selectedAzione.equals(sceltaStringa)){
            String testo = AggiungiStringaController.stringa;
            String path = AggiungiStringaController.percorsoFile;
            a = new AggiungiStringa(path, testo);
        }
        if (selectedAzione.equals(sceltaEliminaFile)) {
            a = path;
        }
        if (selectedAzione.equals(sceltaCopiaSposta)){
            a = new CopiaSposta(SorgenteDestinazioneController.percorsoFile, SorgenteDestinazioneController.destinazione);
        }

        Regola r = null;
        if (ripetibile.isSelected()) {
            r = new Regola(nome, t, a, true, false, true, IbernazioneController.periodoIbernazione);
        }
        else {
            //CREO LA REGOLA !!!
            r = new Regola(nome, t, a, true, false, false);
        }


        GestoreRegole gr = new GestoreRegole(lista);
        gr.aggiungiRegola(r);
        gr.saveObjectsToFile();

        if (helloController != null) {
            helloController.aggiornaTabella(Collections.singletonList(r));
        }

        Stage stage = (Stage) inviaButton.getScene().getWindow();
        stage.close();
    }

    @FXML
    private void ripetiAzione() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Ibernazione.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Seleziona il tempo di ibernazione...");
            stage.setScene(new Scene(root));
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
        }
    }

}


