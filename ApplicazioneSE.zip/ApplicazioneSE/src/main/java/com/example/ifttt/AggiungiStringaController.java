package com.example.ifttt;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;

public class AggiungiStringaController {


    @FXML
    private Button fileButton;
    @FXML
    private TextField testoUtente;
    @FXML
    private Button inviaButton;

    public static String percorsoFile;
    public static String stringa;

    @FXML
    private void initialize() {
        fileButton.setOnAction(event -> scegliFile());
        inviaButton.setOnAction(event -> inviaTutto());
    }


    public void scegliFile() {
        try {
            // Creare un oggetto FileChooser
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Seleziona un file di testo (.txt)");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("File di testo", "*.txt")
            );

            Stage stage = (Stage) fileButton.getScene().getWindow();
            File fileSelezionato = fileChooser.showOpenDialog(stage);


            // Verifica se è stato selezionato un file
            if (fileSelezionato != null) {
                // Salva il percorso del file selezionato
                percorsoFile = fileSelezionato.getAbsolutePath();
            }

        } catch (Exception e) {
            e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
        }
    }



    public void inviaTutto() {

        stringa = testoUtente.getText();


        Stage stage = (Stage) inviaButton.getScene().getWindow();
        stage.close();

    }
}
