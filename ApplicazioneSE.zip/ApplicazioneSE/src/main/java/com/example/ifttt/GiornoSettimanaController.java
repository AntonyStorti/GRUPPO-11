package com.example.ifttt;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.collections.FXCollections;
import javafx.stage.Stage;

import java.time.DayOfWeek;

public class GiornoSettimanaController {


    public static DayOfWeek giorno;

    @FXML
    private Button inviaButton;
    @FXML
    private ChoiceBox<String> giornoBox;



    @FXML
    private void initialize() {
        inviaButton.setOnAction(event -> inviaGiorno());
    }


    public void inviaGiorno() {


        String g = giornoBox.getValue();

        giorno = convertiStringaInDayOfWeek(g);


        Stage stage = (Stage) inviaButton.getScene().getWindow();
        stage.close();

    }

    private DayOfWeek convertiStringaInDayOfWeek(String g) {
        switch (g) {
            case "Lunedì":
                return DayOfWeek.MONDAY;
            case "Martedì":
                return DayOfWeek.TUESDAY;
            case "Mercoledì":
                return DayOfWeek.WEDNESDAY;
            case "Giovedì":
                return DayOfWeek.THURSDAY;
            case "Venerdì":
                return DayOfWeek.FRIDAY;
            case "Sabato":
                return DayOfWeek.SATURDAY;
            case "Domenica":
                return DayOfWeek.SUNDAY;
            default:
                throw new IllegalArgumentException("Stringa giorno non valida!");
        }
    }


}
