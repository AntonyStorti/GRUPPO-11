package com.example.ifttt;

import java.io.Serializable;

public class FinestraDialogo implements Azione, Serializable {


    String testoUtente;


    public FinestraDialogo(String testoUtente) {
        this.testoUtente = testoUtente;
    }



    @Override
    public void eseguiAzione() {

    }

    @Override
    public String toString() {
        return "Visualizza un messaggio a video";
    }
}
