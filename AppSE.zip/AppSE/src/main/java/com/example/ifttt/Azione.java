package com.example.ifttt;

    public interface Azione {

        void eseguiAzione();
        @Override
        String toString();

    }
