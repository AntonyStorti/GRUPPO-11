package com.example.ifttt;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class HelloApplication extends Application {
    private static Thread threadRulesChecker;
    private static ObservableList<Regola> lista = GestoreRegole.listaRegole;


    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("HomePage.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1000, 750);
        stage.setTitle("Applicazione IFTTT [Gruppo 11 (I-Z)]");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        //Initialization and start of the thread for automatic condition checking
        GestoreRegole gr = new GestoreRegole(lista);
        Path path = Paths.get("ListaRegole.ser");

        // Verifica se il file esiste
        if (Files.exists(path)) {
            System.out.println("Il file esiste già.");

        } else {
            try {
                // Crea il file se non esiste
                Files.createFile(path);
                System.out.println("Il file è stato creato con successo.");
            } catch (IOException e) {
                e.printStackTrace();
                System.err.println("Errore durante la creazione del file.");
            }
        }
        threadRulesChecker = new Thread(gr);
        threadRulesChecker.setName("Thread Gestore Regole");
        threadRulesChecker.setDaemon(true);
        threadRulesChecker.start();
        launch();
    }
}
