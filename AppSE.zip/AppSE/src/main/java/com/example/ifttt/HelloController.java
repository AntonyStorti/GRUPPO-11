package com.example.ifttt;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.List;


public class HelloController {

    @FXML
    private Button creaRegolaButton;
    @FXML
    private TableView<Regola> tabellaRegole;
    @FXML
    private TableColumn<Regola, Integer> idRegola;
    @FXML
    private TableColumn<Regola, String> nomeRegola;
    @FXML
    private TableColumn<Regola, Trigger> triggerRegola;
    @FXML
    private TableColumn<Regola, Azione> azioneRegola;
    @FXML
    private TableColumn<Regola, Boolean> ripetibilita;
    @FXML
    private TableColumn<Regola, Boolean> stato;

    @FXML
    private void initialize() {
        idRegola.setCellValueFactory(new PropertyValueFactory<>("ID"));
        nomeRegola.setCellValueFactory(new PropertyValueFactory<>("nome"));
        triggerRegola.setCellValueFactory(new PropertyValueFactory<>("trigger"));
        azioneRegola.setCellValueFactory(new PropertyValueFactory<>("azione"));
        ripetibilita.setCellValueFactory(new PropertyValueFactory<>("eseguito"));
        stato.setCellValueFactory(new PropertyValueFactory<>("stato"));
        caricaDatiDaFile();
        creaRegolaButton.setOnAction(event -> apriFinestraCreazioneRegola());
    }

    @FXML
    private void apriFinestraCreazioneRegola() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("OperaSullaRegola.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Crea la tua Regola...");
            stage.setScene(new Scene(root));

            CreaRegolaController controller = loader.getController();
            controller.setHelloController(this);

            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Gestisci l'eccezione in modo adeguato
        }
    }

    public void eliminaRegola(ActionEvent actionEvent) {
    }

    private void caricaDatiDaFile() {
        tabellaRegole.getItems().clear();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ListaRegole.ser"))) {
            List<Regola> list = (List<Regola>) ois.readObject();
            ObservableList<Regola> obList = FXCollections.observableArrayList(list);
            tabellaRegole.getItems().addAll(obList);
            System.out.println("Dati letti dal file: " + list);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }




    public void aggiornaTabella(List<Regola> nuoveRegole) {
        ObservableList<Regola> observableList = FXCollections.observableArrayList(nuoveRegole);
        tabellaRegole.getItems().addAll(observableList);
    }
}