package com.example.ifttt;

    public interface Trigger {

        boolean verificaCondizione();

    }