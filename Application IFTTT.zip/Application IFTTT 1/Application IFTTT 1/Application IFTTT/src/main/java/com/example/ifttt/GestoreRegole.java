package com.example.ifttt;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;


public class GestoreRegole implements Runnable {


    public static ObservableList<Regola> listaRegole = CreaRegolaController.lista;
    private final int ripetiVerifica = 3;


    public GestoreRegole(ObservableList<Regola> listaRegole) {
        this.listaRegole = listaRegole;
    }


    @Override
    public void run() {

        while (!Thread.currentThread().isInterrupted()) {

            synchronized (listaRegole) {

                //Itero sugli elementi della lista//
                for (Regola a : listaRegole) {
                    a.valutaEsecuzione();
                    System.out.println(listaRegole.toString());
                }
            }

            try {

                Thread.sleep(ripetiVerifica * 1000);

            } catch (InterruptedException ex) {

                Logger.getLogger(GestoreRegole.class.getName());

            }

        }

    }


    //-----METODI PER GESTIRE LE REGOLE-----//
    public void addRegola(Regola nuovaRegola) {
        listaRegole.add(nuovaRegola);
    }

    // Metodo per rimuovere una regola dalla lista
    public void removeRegola(Regola regolaDaRimuovere) {
        listaRegole.remove(regolaDaRimuovere);
    }


    public void attivaRegola(Regola regolaDaAttivare) {
        regolaDaAttivare.setStato(true);
    }

    public void disattivaRegola(Regola regolaDaDisattivare) {
        regolaDaDisattivare.setStato(false);
    }

    @Override
    public String toString() {
        return "GestoreRegole{" +
                "listaRegole=" + listaRegole +
                '}';
    }

    public void saveObjectsToFile() {
        List<Regola> listaSerializzabile = new ArrayList<>(listaRegole);
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ListaRegole.ser", true))) {
            // Scrivi la lista di oggetti sul file
            oos.writeObject(listaSerializzabile);
            System.out.println("Oggetti salvati con successo nel file.");
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("Errore durante il salvataggio degli oggetti nel file.");
        }
    }

    public void loadObjectsFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ListaRegole.ser"))) {
            List<Regola> listaSerializzabile = (List<Regola>) ois.readObject();
            ObservableList<Regola> listaOsservabile = FXCollections.observableArrayList(listaSerializzabile);
            listaRegole.addAll(listaOsservabile);

            System.out.println("Oggetti caricati con successo dal file.");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            System.err.println("Errore durante il caricamento degli oggetti dal file.");
        }
    }

}